plugins {
    id("com.google.devtools.ksp")
    id("androidx.room")
}

dependencies {
    val roomVersion = "2.8.4"
    implementation("androidx.room:room-runtime:$roomVersion")
    implementation("androidx.room:room-ktx:$roomVersion")
    ksp("androidx.room:room-compiler:$roomVersion")
}

room {
    schemaDirectory("$projectDir/schemas")
}
