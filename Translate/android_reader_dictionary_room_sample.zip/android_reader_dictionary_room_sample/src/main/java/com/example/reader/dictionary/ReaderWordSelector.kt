package com.example.reader.dictionary

import java.text.BreakIterator
import java.util.Locale

/**
 * Minimal helper for selecting the token under a tap/cursor position.
 * For Japanese and Chinese you can later replace this with Kuromoji / a dedicated segmenter.
 */
object ReaderWordSelector {
    fun selectToken(
        text: CharSequence,
        offset: Int,
        lang: LanguageCode,
    ): TokenSelection? {
        if (text.isEmpty()) return null
        val safeOffset = offset.coerceIn(0, text.length - 1)
        val locale = when (lang) {
            LanguageCode.EN -> Locale.ENGLISH
            LanguageCode.JA -> Locale.JAPANESE
            LanguageCode.ZH -> Locale.CHINESE
            LanguageCode.RU -> Locale("ru")
            LanguageCode.KO -> Locale.KOREAN
        }

        val iterator = BreakIterator.getWordInstance(locale)
        iterator.setText(text.toString())

        var start = iterator.preceding(safeOffset + 1)
        var end = iterator.following(safeOffset)

        if (start == BreakIterator.DONE || end == BreakIterator.DONE || start >= end) {
            return null
        }

        while (start < end && text[start].isTokenTrimChar()) start++
        while (end > start && text[end - 1].isTokenTrimChar()) end--
        if (start >= end) return null

        val surface = text.substring(start, end)
        return TokenSelection(surface = surface, start = start, endExclusive = end)
    }

    private fun Char.isTokenTrimChar(): Boolean {
        return isWhitespace() || this in punctuationChars
    }

    private val punctuationChars = setOf(
        '.', ',', ';', ':', '!', '?', '"', '\'', '(', ')', '[', ']', '{', '}', '<', '>',
        '/', '\\', '|', '-', '—', '–', '…', '«', '»', '“', '”', '„', '’', '‘'
    )
}
