package com.example.reader.dictionary

class DictionaryRepository(
    private val dao: DictionaryDao,
) {
    suspend fun lookup(
        surface: String,
        lang: LanguageCode,
        preferredTargetLang: String? = null,
        limit: Int = 8,
    ): List<LookupCard> {
        val normalized = DictionaryNormalizer.normalize(surface, lang)
        if (normalized.isBlank()) return emptyList()

        val primary = dao.lookupByNormalizedForm(lang.code, normalized, limit)
        val fallback = if (primary.isEmpty()) {
            dao.lookupByNormalizedLemma(lang.code, normalized, limit)
        } else {
            emptyList()
        }

        val bundles = if (primary.isNotEmpty()) primary else fallback
        return bundles.map { it.toLookupCard(preferredTargetLang) }
    }

    suspend fun suggest(
        prefix: String,
        lang: LanguageCode,
        limit: Int = 12,
    ): List<String> {
        val normalized = DictionaryNormalizer.normalize(prefix, lang)
        if (normalized.isBlank()) return emptyList()
        return dao.suggestForms(lang.code, normalized, limit)
    }
}

private fun EntryBundle.toLookupCard(preferredTargetLang: String?): LookupCard {
    val lang = LanguageCode.fromCode(entry.lang)
        ?: error("Unsupported language code in DB: ${entry.lang}")

    val filteredTranslations = translations
        .sortedBy { it.ord }
        .let { items ->
            if (preferredTargetLang.isNullOrBlank()) items
            else items.filter { it.targetLang == preferredTargetLang }.ifEmpty { items }
        }
        .map { it.text }
        .distinct()
        .take(6)

    return LookupCard(
        entryId = entry.id,
        lang = lang,
        lemma = entry.lemma,
        pos = entry.pos.ifBlank { null },
        source = entry.source,
        readings = readings
            .sortedBy { it.script + "\u0000" + it.text }
            .map { it.text }
            .distinct(),
        meanings = senses
            .sortedBy { it.ord }
            .map { it.gloss }
            .distinct()
            .take(4),
        translations = filteredTranslations,
        examples = examples
            .map { LookupExample(text = it.text, translation = it.translation) }
            .take(3),
    )
}
