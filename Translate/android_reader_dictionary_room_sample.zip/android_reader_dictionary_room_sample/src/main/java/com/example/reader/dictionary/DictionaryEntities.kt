package com.example.reader.dictionary

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "entries",
    indices = [
        Index(
            value = ["lang", "normalized_lemma", "pos", "source"],
            unique = true,
            name = "idx_entries_unique"
        )
    ]
)
data class EntryEntity(
    @PrimaryKey
    val id: Long,
    val lang: String,
    val lemma: String,
    @ColumnInfo(name = "normalized_lemma")
    val normalizedLemma: String,
    val pos: String,
    val source: String,
)

@Entity(
    tableName = "forms",
    foreignKeys = [
        ForeignKey(
            entity = EntryEntity::class,
            parentColumns = ["id"],
            childColumns = ["entry_id"],
            onDelete = ForeignKey.CASCADE,
        )
    ],
    indices = [
        Index(value = ["lang", "normalized_form"], name = "idx_forms_lang_norm")
    ]
)
data class FormEntity(
    @PrimaryKey
    val id: Long,
    val lang: String,
    val form: String,
    @ColumnInfo(name = "normalized_form")
    val normalizedForm: String,
    @ColumnInfo(name = "entry_id")
    val entryId: Long,
)

@Entity(
    tableName = "senses",
    foreignKeys = [
        ForeignKey(
            entity = EntryEntity::class,
            parentColumns = ["id"],
            childColumns = ["entry_id"],
            onDelete = ForeignKey.CASCADE,
        )
    ]
)
data class SenseEntity(
    @PrimaryKey
    val id: Long,
    @ColumnInfo(name = "entry_id")
    val entryId: Long,
    val ord: Int,
    val gloss: String,
)

@Entity(
    tableName = "translations",
    foreignKeys = [
        ForeignKey(
            entity = EntryEntity::class,
            parentColumns = ["id"],
            childColumns = ["entry_id"],
            onDelete = ForeignKey.CASCADE,
        )
    ]
)
data class TranslationEntity(
    @PrimaryKey
    val id: Long,
    @ColumnInfo(name = "entry_id")
    val entryId: Long,
    @ColumnInfo(name = "target_lang")
    val targetLang: String,
    val text: String,
    val ord: Int,
)

@Entity(
    tableName = "readings",
    foreignKeys = [
        ForeignKey(
            entity = EntryEntity::class,
            parentColumns = ["id"],
            childColumns = ["entry_id"],
            onDelete = ForeignKey.CASCADE,
        )
    ]
)
data class ReadingEntity(
    @PrimaryKey
    val id: Long,
    @ColumnInfo(name = "entry_id")
    val entryId: Long,
    val script: String,
    val text: String,
)

@Entity(
    tableName = "examples",
    foreignKeys = [
        ForeignKey(
            entity = EntryEntity::class,
            parentColumns = ["id"],
            childColumns = ["entry_id"],
            onDelete = ForeignKey.CASCADE,
        )
    ]
)
data class ExampleEntity(
    @PrimaryKey
    val id: Long,
    @ColumnInfo(name = "entry_id")
    val entryId: Long,
    val text: String,
    val translation: String?,
)
