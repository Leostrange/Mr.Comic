package com.example.reader.dictionary

import android.content.Context

class DictionaryService private constructor(
    private val repository: DictionaryRepository,
) {
    suspend fun lookupTappedWord(
        fullText: CharSequence,
        tapOffset: Int,
        bookLanguage: LanguageCode,
        preferredTargetLang: String? = null,
    ): List<LookupCard> {
        val selection = ReaderWordSelector.selectToken(fullText, tapOffset, bookLanguage)
            ?: return emptyList()

        return repository.lookup(
            surface = selection.surface,
            lang = bookLanguage,
            preferredTargetLang = preferredTargetLang,
        )
    }

    companion object {
        fun fromAsset(
            context: Context,
            assetPath: String = "databases/dictionary.db",
        ): DictionaryService {
            val db = DictionaryDatabase.fromAsset(context, assetPath = assetPath)
            return DictionaryService(DictionaryRepository(db.dictionaryDao()))
        }
    }
}
