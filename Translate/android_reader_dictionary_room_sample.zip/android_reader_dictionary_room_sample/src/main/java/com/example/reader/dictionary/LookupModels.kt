package com.example.reader.dictionary

enum class LanguageCode(val code: String) {
    EN("en"),
    JA("ja"),
    ZH("zh"),
    RU("ru"),
    KO("ko");

    companion object {
        fun fromCode(code: String): LanguageCode? = values().firstOrNull { it.code == code }
    }
}

data class LookupExample(
    val text: String,
    val translation: String?,
)

data class LookupCard(
    val entryId: Long,
    val lang: LanguageCode,
    val lemma: String,
    val pos: String?,
    val source: String,
    val readings: List<String>,
    val meanings: List<String>,
    val translations: List<String>,
    val examples: List<LookupExample>,
)

data class TokenSelection(
    val surface: String,
    val start: Int,
    val endExclusive: Int,
)
