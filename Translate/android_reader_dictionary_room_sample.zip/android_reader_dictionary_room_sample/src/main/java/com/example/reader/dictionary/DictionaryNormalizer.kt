package com.example.reader.dictionary

import java.text.Normalizer
import java.util.Locale

object DictionaryNormalizer {
    private val cjkLangs = setOf("ja", "zh", "ko")

    fun normalize(text: String, lang: LanguageCode): String {
        val collapsed = WHITESPACE.replace(
            Normalizer.normalize(text, Normalizer.Form.NFKC).trim(),
            " "
        )
        return if (lang.code in cjkLangs) collapsed else collapsed.lowercase(Locale.ROOT)
    }

    private val WHITESPACE = Regex("\\s+")
}
