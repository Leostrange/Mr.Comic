package com.example.reader.dictionary

import androidx.room.Embedded
import androidx.room.Relation

data class EntryBundle(
    @Embedded
    val entry: EntryEntity,
    @Relation(parentColumn = "id", entityColumn = "entry_id")
    val senses: List<SenseEntity>,
    @Relation(parentColumn = "id", entityColumn = "entry_id")
    val translations: List<TranslationEntity>,
    @Relation(parentColumn = "id", entityColumn = "entry_id")
    val readings: List<ReadingEntity>,
    @Relation(parentColumn = "id", entityColumn = "entry_id")
    val examples: List<ExampleEntity>,
)
