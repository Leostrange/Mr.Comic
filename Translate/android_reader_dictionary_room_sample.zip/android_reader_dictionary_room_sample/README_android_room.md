# Android Room sample for the offline reader dictionary

This sample matches the SQLite schema produced by the **Room-compatible** build script:
- `entries`
- `forms`
- `senses`
- `translations`
- `readings`
- `examples`

## What is included

- `DictionaryEntities.kt` - Room entities matching the DB tables
- `DictionaryRelations.kt` - one-to-many relations for entry details
- `DictionaryDao.kt` - lookup and suggestion queries
- `DictionaryDatabase.kt` - `createFromAsset()` / `createFromFile()` setup
- `DictionaryRepository.kt` - surface -> normalized token -> lookup cards
- `ReaderWordSelector.kt` - minimal token selection helper for a tap position
- `SampleUsage.kt` - tiny service wrapper you can call from your reader

## Gradle (Kotlin DSL)

```kotlin
plugins {
    id("com.android.application")
    kotlin("android")
    id("com.google.devtools.ksp")
    id("androidx.room")
}

android {
    namespace = "com.example.reader"
}

dependencies {
    val roomVersion = "2.8.4"

    implementation("androidx.room:room-runtime:$roomVersion")
    implementation("androidx.room:room-ktx:$roomVersion")
    ksp("androidx.room:room-compiler:$roomVersion")
}

room {
    schemaDirectory("$projectDir/schemas")
}
```

## Asset layout

If you build one combined DB:

```text
app/src/main/assets/databases/dictionary.db
```

If you build per-language DB files, open them with `createFromFile()` after downloading or copying them to app storage.

## Minimal call site

```kotlin
val service = DictionaryService.fromAsset(context)
val cards = service.lookupTappedWord(
    fullText = chapterText,
    tapOffset = selectionOffset,
    bookLanguage = LanguageCode.JA,
    preferredTargetLang = "ru",
)
```

## Important

This sample expects the SQLite file to be built with a **Room-compatible schema**:
- `entries.pos` should be `TEXT NOT NULL DEFAULT ''`
- the unique index on `entries` should be a normal composite index on
  `(lang, normalized_lemma, pos, source)`
- the DB header `user_version` should be set to `1`

If you keep the earlier expression index `IFNULL(pos, '')`, Room schema validation can fail.

## Practical note on tokenization

`ReaderWordSelector` is a simple fallback. It is acceptable for EN/RU and as a baseline for KO.
For better Japanese word selection, replace it later with a Kuromoji-based selector.
For Chinese, a dedicated segmenter will improve results over generic boundary analysis.
